var mathlib = require("./mathlib");
console.log(mathlib);
mathlib.add(4,5);
mathlib.multiply(5,9);
mathlib.square(4);
