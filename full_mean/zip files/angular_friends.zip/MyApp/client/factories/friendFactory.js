myApp.factory('friendFactory', function($http){
  var _friend;
  var factory = {};
  factory.create = function(friend, callback){
    console.log("create method friendFactory");
    console.log(friend, "this is the friend object");
    $http.post("/friends", friend).then(function(data){
      _friend = data.data;
      callback(data);
    })
  }

  factory.getFriend = function(callback){
    callback(_friend);
  }

  return factory;
})
