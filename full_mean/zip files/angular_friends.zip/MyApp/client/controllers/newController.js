myApp.controller('newController', function($scope, $location, friendFactory){
  $scope.addFriend = function(){
    console.log("Adding a friend newController", $scope.user);
    friendFactory.create($scope.friend, function(data){
      console.log("this is going to run after data gets from server friendFactory");
      console.log(data);
      if(data.data.error){
        $scope.error = data.data.error;
      } else {
        $location.path("/friends");
      }
    });
  }
})
