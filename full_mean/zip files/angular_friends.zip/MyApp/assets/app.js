var myApp = angular.module('myApp', ['ngRoute']);

(function(){
  myApp.config(['$routeProvider', function($routeProvider){
  $routeProvider
    .when('/friends/new',
    {
      controller: 'newController',
      templateUrl: "partials/friends/new.html"
    })
    .when('/friends/:id',{
      templateUrl: "partials/friends/edit.html"
  })
}]);


