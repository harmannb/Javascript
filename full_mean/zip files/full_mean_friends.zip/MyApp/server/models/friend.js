console.log('friends model');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var FriendSchema = new mongoose.Schema({
    name: {type: String},
    age: {type: Number}
});

mongoose.model("Friend", FriendSchema);

var Friend = mongoose.model("Friend")

Friend.create({name:"Harmann", age:22}, function(err) {
  if (err) {
    console.log("there is an error")
  }
})
