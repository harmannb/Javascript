console.log('friends controller');
var mongoose = require('mongoose');
var Friend = mongoose.model("Friend");

function FriendsController(){
  this.index = function(req,res){
    console.log('creating a FriendsController')
    res.json({placeholder:'index'});
  };
  this.create = function(req,res){
    console.log('this is the friends name', req.body.name)
    var newFriend = new Friend({friend_name: req.body.name})
    newFriend.save(function(err, result){
      if (err) {
        console.log('there was an error when saving friend', err);
      } else {
        res.json(result)
      }
    })
    res.json({placeholder:'create'});
  };
  this.update = function(req,res){
    //your code here
    res.json({placeholder:'update'});
  };
  this.delete = function(req,res){
    //your code here
    res.json({placeholder:'delete'});
  };
  this.show = function(req,res){
    //your code here
    res.json({placeholder:'show'});
  };
}
module.exports = new FriendsController(); //


